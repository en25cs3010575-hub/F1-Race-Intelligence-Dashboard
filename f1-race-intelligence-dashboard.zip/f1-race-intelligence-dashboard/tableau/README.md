# Tableau Workbook

Place your exported workbook here:
- `f1_race_intelligence.twbx` (packaged workbook - recommended, includes data)
- or `f1_race_intelligence.twb` + `data/processed/f1_clean.csv`

**To export:** Tableau Desktop → *File → Export As Packaged Workbook...*

**Tableau Public link:** `<paste here after publishing>`

Suggested sheets: Points Trajectory · Tyre Strategy · Circuit Participation ·
Driver Reliability (stacked bar) · Podium Distribution · GP Host Countries · Driver Leaderboard
