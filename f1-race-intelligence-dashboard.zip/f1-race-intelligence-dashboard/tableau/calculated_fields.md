# Tableau Calculated Fields

```
// Podium Flag
IF [position] <= 3 THEN 1 ELSE 0 END

// DNF Rate
SUM([is_dnf]) / COUNT([driver])

// Reliability Score (higher = better)
1 - ( SUM([is_dnf]) / COUNT([driver]) )

// Win Rate
SUM([is_win]) / COUNT([driver])

// Cumulative Points (Table Calc, compute along Season)
RUNNING_SUM(SUM([points]))

// Avg Positions Gained
AVG([positions_gained])

// Podium % by Team
SUM([is_podium]) / COUNT([driver])
```
