"""Generate SYNTHETIC F1-style data (6,464 rows, 17 seasons) for pipeline testing.
NOT real F1 results - do not publish insights from this file.
"""
from pathlib import Path

import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
N, SEASONS = 6464, list(range(2008, 2025))
TEAMS = ["Red Bull Racing", "Mercedes", "Ferrari", "McLaren", "Alpine",
         "Aston Martin", "Williams", "Haas", "Sauber", "AlphaTauri"]
CIRCUITS = {"Silverstone": ("British GP", "UK"), "Monza": ("Italian GP", "Italy"),
            "Spa": ("Belgian GP", "Belgium"), "Suzuka": ("Japanese GP", "Japan"),
            "Interlagos": ("Brazilian GP", "Brazil"), "Monaco": ("Monaco GP", "Monaco"),
            "Albert Park": ("Australian GP", "Australia"), "Marina Bay": ("Singapore GP", "Singapore")}
NATS = ["British", "German", "Dutch", "Spanish", "Finnish", "French", "Australian", "Brazilian", "Japanese"]
STATUS = ["Finished"] * 14 + ["Engine", "Brakes", "Collision", "Mechanical"]
POINTS = {1: 25, 2: 18, 3: 15, 4: 12, 5: 10, 6: 8, 7: 6, 8: 4, 9: 2, 10: 1}

rows = []
circ = list(CIRCUITS)
for i in range(N):
    c = circ[rng.integers(len(circ))]
    status = rng.choice(STATUS)
    pos = np.nan if status != "Finished" else int(rng.integers(1, 21))
    rows.append({
        "season": int(rng.choice(SEASONS)), "round": int(rng.integers(1, 23)),
        "grand_prix": CIRCUITS[c][0], "circuit": c, "country": CIRCUITS[c][1],
        "driver": f"Driver {rng.integers(1, 61):02d}", "nationality": rng.choice(NATS),
        "team": rng.choice(TEAMS), "grid": int(rng.integers(1, 21)), "position": pos,
        "points": POINTS.get(pos, 0) if pos == pos else 0, "status": status,
        "tyre_compound": rng.choice(["Soft", "Medium", "Hard", "Intermediate"], p=[.3, .4, .25, .05]),
    })

out = Path("data/raw/f1_races.csv")
out.parent.mkdir(parents=True, exist_ok=True)
pd.DataFrame(rows).to_csv(out, index=False)
print(f"Wrote {N} synthetic rows -> {out}")
