"""Clean the raw F1 dataset and create derived columns for Tableau.

Usage:
    python scripts/prepare_data.py [--input data/raw/f1_races.csv]
                                   [--output data/processed/f1_clean.csv]
"""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd

REQUIRED = ["season", "round", "grand_prix", "circuit", "country", "driver",
            "nationality", "team", "grid", "position", "points", "status",
            "tyre_compound"]

# Adjust if your raw column names differ
RENAME = {"year": "season", "race": "grand_prix", "constructor": "team",
          "finish_position": "position", "tyre": "tyre_compound"}

FAILURE_MAP = {
    "engine": "Engine", "brake": "Brakes", "brakes": "Brakes",
    "collision": "Collision", "accident": "Collision",
    "gearbox": "Mechanical", "hydraulics": "Mechanical",
    "suspension": "Mechanical", "mechanical": "Mechanical",
}


def failure_type(status: str) -> str:
    s = str(status).lower()
    if s.startswith("finished") or s.startswith("+"):
        return "Finished"
    for key, val in FAILURE_MAP.items():
        if key in s:
            return val
    return "Other"


def main(inp: Path, out: Path) -> None:
    df = pd.read_csv(inp)
    df = df.rename(columns={k: v for k, v in RENAME.items() if k in df.columns})

    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        raise SystemExit(f"Missing columns: {missing}. Edit RENAME in this script.")

    df = df[REQUIRED].copy()
    n0 = len(df)

    # --- cleaning ---
    df = df.drop_duplicates()
    for c in ["driver", "team", "country", "circuit", "grand_prix",
              "nationality", "status", "tyre_compound"]:
        df[c] = df[c].astype(str).str.strip()
    df["tyre_compound"] = df["tyre_compound"].str.title().replace(
        {"Nan": "Unknown", "": "Unknown"})
    for c in ["season", "round", "grid", "position", "points"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["points"] = df["points"].fillna(0)
    df = df.dropna(subset=["season", "round", "driver", "team"])

    # --- derived columns ---
    df["failure_type"] = df["status"].apply(failure_type)
    df["is_dnf"] = (df["failure_type"] != "Finished").astype(int)
    df["is_win"] = (df["position"] == 1).astype(int)
    df["is_podium"] = (df["position"] <= 3).astype(int)
    df["positions_gained"] = np.where(
        df["grid"].gt(0) & df["position"].notna(), df["grid"] - df["position"], np.nan)

    out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, index=False)
    print(f"Rows: {n0} -> {len(df)} | seasons: {int(df.season.nunique())} | saved: {out}")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--input", default="data/raw/f1_races.csv", type=Path)
    p.add_argument("--output", default="data/processed/f1_clean.csv", type=Path)
    a = p.parse_args()
    main(a.input, a.output)
