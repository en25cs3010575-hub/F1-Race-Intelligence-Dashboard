# 🏎️ Formula 1 Race Intelligence Dashboard (Tableau)

An interactive **Tableau** analytics project exploring 17 seasons of Formula 1 racing (**6,464 race records**): driver performance, team championship trajectories, tyre compound strategy, circuit participation, reliability / DNF analysis and global podium achievements.

> Built as part of the **Skill Wallet (SmartBridge)** project programme. Skills: Tableau · Dashboard Design · Data Visualization · Data Preprocessing.

---

## 📌 Table of Contents
- [Project Overview](#-project-overview)
- [Scenarios](#-scenarios)
- [Technical Architecture](#-technical-architecture)
- [Repository Structure](#-repository-structure)
- [Getting Started](#-getting-started)
- [Data Schema](#-data-schema)
- [Project Phases](#-project-phases)
- [System Requirements](#-system-requirements)
- [Screenshots](#-screenshots)
- [Author](#-author)

## 📖 Project Overview
This project turns raw F1 race results into a visual decision-support tool for team strategists, race engineers, motorsport journalists and fans. Tableau was used to build worksheets, a dashboard and a story that let stakeholders:
- Track **championship points trajectories** across seasons
- Compare **tyre compound strategies** (Soft, Medium, Hard, Intermediate) and their effect on race outcomes
- Analyse **circuit-level** participation and **countries hosting** the most Grand Prix rounds
- Evaluate **driver reliability** and **DNF causes** (engine, brakes, collisions, mechanical)
- Visualise **podium distributions** by driver, team and nationality

## 🎭 Scenarios
| # | Persona | Goal |
|---|---------|------|
| 1 | **F1 Team Performance Strategist** | Benchmark points trajectory vs. top teams, evaluate tyre strategies, find strong talent pools by nationality |
| 2 | **Motorsport Broadcast Analyst** | Pull leaderboards, top Grand Prix host countries and podium infographics for broadcast/editorial content |
| 3 | **F1 Technical Regulation Analyst** | Study DNF patterns and reliability scores across 17 seasons to assess regulatory impact |

## 🏗️ Technical Architecture
```mermaid
flowchart LR
    A[(Data Source<br/>Excel / CSV / SQL)] --> B[Tableau<br/>Data Connection]
    B --> C[Data Preparation<br/>Cleaning & Calculated Fields]
    C --> D[Worksheets<br/>Visualizations]
    D --> E[Dashboard & Story]
    E --> F[Tableau Public / Web Integration]
    F --> G((End Users))
```

## 📁 Repository Structure
```
f1-race-intelligence-dashboard/
├── README.md
├── LICENSE
├── requirements.txt
├── .gitignore
├── data/
│   ├── raw/                  # put original dataset here
│   └── processed/            # cleaned CSV used by Tableau
├── scripts/
│   ├── prepare_data.py       # cleaning + derived columns
│   └── generate_sample_data.py  # synthetic demo data (for testing only)
├── tableau/
│   ├── README.md             # where to place .twbx / .twb
│   └── calculated_fields.md  # all Tableau calculations
└── docs/
    ├── PROJECT_REPORT.md
    ├── DASHBOARD_GUIDE.md
    └── screenshots/
```

## 🚀 Getting Started
```bash
# 1. Clone
git clone https://github.com/<your-username>/f1-race-intelligence-dashboard.git
cd f1-race-intelligence-dashboard

# 2. Install
pip install -r requirements.txt

# 3. Put your dataset in data/raw/f1_races.csv, then clean it
python scripts/prepare_data.py

# (No dataset yet? Generate SYNTHETIC demo data to test the pipeline)
python scripts/generate_sample_data.py
python scripts/prepare_data.py

# 4. Open Tableau, connect to data/processed/f1_clean.csv
#    and build / open the workbook in tableau/
```

## 🗂️ Data Schema
Expected columns (rename in `prepare_data.py` if your dataset differs):

| Column | Description |
|--------|-------------|
| `season` | Year of the season |
| `round` | Round number in the season |
| `grand_prix` | Grand Prix name |
| `circuit` | Circuit name |
| `country` | Host country |
| `driver` | Driver name |
| `nationality` | Driver nationality |
| `team` | Constructor |
| `grid` | Starting position |
| `position` | Finishing position (blank if DNF) |
| `points` | Points scored |
| `status` | Finished / Engine / Brakes / Collision / Mechanical ... |
| `tyre_compound` | Soft / Medium / Hard / Intermediate |

Derived by the script: `is_dnf`, `is_podium`, `is_win`, `positions_gained`, `failure_type`.

## 🧭 Project Phases
1. Data Collection & Extraction from Database
2. Data Preparation
3. Data Visualization
4. Dashboard
5. Story
6. Performance Testing
7. Web Integration
8. Project Demonstration & Documentation

Details: [`docs/DASHBOARD_GUIDE.md`](docs/DASHBOARD_GUIDE.md)

## 💻 System Requirements
- **CPU:** Dual-core (i3 or equivalent) — recommended i5 / Ryzen 5+
- **RAM:** min 8 GB — recommended 16 GB
- **Storage:** min 2–3 GB free — recommended SSD with 10+ GB
- **OS:** Windows 10/11 (64-bit) or macOS (latest)
- **Software:** Tableau Desktop or Tableau Public
- **Browser:** latest Chrome, Edge or Safari
- **Data sources:** Excel, CSV or SQL databases

## 🖼️ Screenshots
| Overview | Scenarios & Skills | Architecture |
|---|---|---|
| ![overview](docs/screenshots/01-overview.png) | ![scenarios](docs/screenshots/02-scenarios-skills.png) | ![arch](docs/screenshots/03-architecture-requirements.png) |

## 👤 Author
**Ali** — CSE student, aspiring AI/ML Engineer.
- GitHub: `https://github.com/<your-username>`
- Tableau Public: `<add your link here>`

## 📄 License
MIT — see [LICENSE](LICENSE).
